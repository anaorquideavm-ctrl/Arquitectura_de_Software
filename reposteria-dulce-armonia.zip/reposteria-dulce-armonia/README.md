# Dulce Armonía - Plataforma Web de Repostería Especializada

Plataforma de comercio electrónico y gestión de inventario para una repostería enfocada en postres saludables, para diabéticos, celíacos e intolerantes a la lactosa.

## Tecnologías Utilizadas
- **Backend:** Node.js, Express, SQL Server (recurso principal CRUD), MongoDB + Mongoose (reseñas/calificaciones), JWT, Bcryptjs.
- **Frontend:** React + Vite, TanStack Query (React Query), React Router DOM.
- **Infraestructura:** Docker (SQL Server & MongoDB).

## Pasos para ejecutar el proyecto

### 1. Levantar las Bases de Datos con Docker
```bash
# SQL Server
docker run -d --name sqlserver -p 1433:1433 \
  -e "ACCEPT_EULA=Y" \
  -e "MSSQL_SA_PASSWORD=TuPassword123!" \
  mcr.microsoft.com/mssql/server:2022-latest

# MongoDB
docker run -d --name mongo -p 27017:27017 mongo:7
```

### 2. Crear las Tablas en SQL Server
Ejecutar el script que se encuentra en `api/tienda.sql` dentro de tu gestor de base de datos o extensión SQL Server de VS Code conectada a `localhost,1433`.

### 3. Configurar Variables de Entorno
Copiar el archivo `.env.example` en la carpeta `api` y renombrarlo a `.env`:
```bash
cp api/.env.example api/.env
```

### 4. Iniciar la API (Backend)
```bash
cd api
npm install
npm run dev
```

### 5. Iniciar el Frontend
```bash
cd ../frontend
npm install
npm run dev
```

---

## Explicación de la Arquitectura (Unidad 3)
El backend está diseñado utilizando **Arquitectura Hexagonal (Puertos y Adaptadores)** dentro del módulo de productos (`src/products`). 

1. **Dominio (`domain/product.schema.js`):** Contiene la lógica pura del negocio y validaciones indispensables de los datos del producto sin depender de ningún framework o base de datos.
2. **Aplicación (`application/product.service.js`):** Define los casos de uso (crear, listar, actualizar, eliminar). Actúa como intermediario ejecutando la validación del dominio y llamando a las interfaces necesarias.
3. **Infraestructura / Adaptadores (`infrastructure/`):** Contiene los adaptadores concretos. `product.routes.js` (Adaptador de Entrada HTTP con Express) traduce las peticiones Web, y `product.repository.js` (Adaptador de Salida SQL) interactúa directamente con la base de datos SQL Server. 

Esta separación desacopla completamente las reglas de negocio de los frameworks y la persistencia de datos.
