import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { pool } from '../db/sqlserver.js';

export async function registro(req, res, next) {
  try {
    const { nombre, email, password } = req.body;
    if (!nombre || !email || !password) return res.status(400).json({ error: 'Faltan campos obligatorios' });

    const hash = await bcrypt.hash(password, 10);
    const r = await pool.request()
      .input('nombre', nombre)
      .input('email', email)
      .input('hash', hash)
      .query(`INSERT INTO usuarios (nombre, email, password_hash)
              OUTPUT INSERTED.id, INSERTED.nombre, INSERTED.email
              VALUES (@nombre, @email, @hash)`);

    res.status(201).json(r.recordset[0]);
  } catch (err) {
    next(err);
  }
}

export async function login(req, res, next) {
  try {
    const { email, password } = req.body;
    if (!email || !password) return res.status(400).json({ error: 'Email y contraseña requeridos' });

    const r = await pool.request()
      .input('email', email)
      .query('SELECT * FROM usuarios WHERE email = @email');

    const usuario = r.recordset[0];
    const ok = usuario && await bcrypt.compare(password, usuario.password_hash);

    if (!ok) return res.status(401).json({ error: 'Credenciales inválidas' });

    const token = jwt.sign(
      { id: usuario.id, nombre: usuario.nombre },
      process.env.JWT_SECRET,
      { expiresIn: '2h' }
    );

    res.json({ token, nombre: usuario.nombre });
  } catch (err) {
    next(err);
  }
}