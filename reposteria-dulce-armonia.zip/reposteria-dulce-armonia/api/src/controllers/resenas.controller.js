import { Resena } from '../models/resena.model.js';

export async function listarResenas(req, res, next) {
  try {
    const filtro = req.query.productoId ? { productoId: Number(req.query.productoId) } : {};
    const resenas = await Resena.find(filtro).sort({ createdAt: -1 });
    res.json(resenas);
  } catch (err) {
    next(err);
  }
}

export async function crearResena(req, res, next) {
  try {
    const nueva = await Resena.create(req.body);
    res.status(201).json(nueva);
  } catch (err) {
    next(err);
  }
}