import express from 'express';
import cors from 'cors';
import mongoose from 'mongoose';
import authRoutes from './routes/auth.routes.js';
import productRoutes from './products/infrastructure/product.routes.js';
import resenaRoutes from './routes/resenas.routes.js';
import { errores } from './middlewares/errores.js';

const app = express();

app.use(cors());
app.use(express.json());

app.use('/api/auth', authRoutes);
app.use('/api/productos', productRoutes);
app.use('/api/resenas', resenaRoutes);

app.use(errores);

await mongoose.connect(process.env.MONGO_URI);
console.log(' Conectado a MongoDB');

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => {
  console.log(` Servidor ejecutándose en http://localhost:${PORT}`);
});