export function errores(err, req, res, next) {
  console.error(err);

  if (err.name === 'ValidationError' || err.name === 'CastError') {
    return res.status(400).json({ error: err.message });
  }

  if (err.code === 11000 || err.number === 2627) {
    return res.status(409).json({ error: 'El registro ya existe en la base de datos' });
  }

  res.status(500).json({ error: 'Error interno del servidor' });
}