import mongoose from 'mongoose';

const resenaSchema = new mongoose.Schema({
  productoId: { type: Number, required: [true, 'El ID del producto es requerido'] },
  cliente: { type: String, required: [true, 'El nombre del cliente es requerido'] },
  comentario: { type: String, required: [true, 'El comentario es requerido'], minlength: 5 },
  calificacion: { type: Number, required: true, min: 1, max: 5 }
}, { timestamps: true });

export const Resena = mongoose.model('Resena', resenaSchema);