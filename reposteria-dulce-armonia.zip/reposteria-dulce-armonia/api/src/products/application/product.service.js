import { validarProducto } from '../domain/product.schema.js';

export class ProductService {
  constructor(productRepository) {
    this.repo = productRepository;
  }

  async listarProductos() {
    return await this.repo.listar();
  }

  async obtenerProducto(id) {
    const prod = await this.repo.obtenerPorId(id);
    if (!prod) throw { status: 404, message: 'Producto no encontrado' };
    return prod;
  }

  async crearProducto(data) {
    const productoValido = validarProducto(data);
    return await this.repo.crear(productoValido);
  }

  async actualizarProducto(id, data) {
    const productoValido = validarProducto(data);
    const actualizado = await this.repo.actualizar(id, productoValido);
    if (!actualizado) throw { status: 404, message: 'Producto no encontrado para actualizar' };
    return actualizado;
  }

  async eliminarProducto(id) {
    const exito = await this.repo.eliminar(id);
    if (!exito) throw { status: 404, message: 'Producto no encontrado para eliminar' };
  }
}