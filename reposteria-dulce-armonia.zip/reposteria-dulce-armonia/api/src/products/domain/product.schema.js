export function validarProducto(data) {
  const { nombre, descripcion, categoria, precio, imagen_url, stock } = data;
  if (!nombre || !descripcion || !categoria || precio === undefined || !imagen_url) {
    throw { status: 400, message: 'Faltan campos obligatorios en el producto' };
  }
  if (precio <= 0) {
    throw { status: 400, message: 'El precio debe ser mayor a 0' };
  }
  return { nombre, descripcion, categoria, precio: Number(precio), imagen_url, stock: Number(stock || 0) };
}