import { pool } from '../../db/sqlserver.js';

export class ProductRepository {
  async listar() {
    const r = await pool.query('SELECT * FROM productos ORDER BY id DESC');
    return r.recordset;
  }

  async obtenerPorId(id) {
    const r = await pool.request()
      .input('id', id)
      .query('SELECT * FROM productos WHERE id = @id');
    return r.recordset[0] || null;
  }

  async crear(p) {
    const r = await pool.request()
      .input('nombre', p.nombre)
      .input('descripcion', p.descripcion)
      .input('categoria', p.categoria)
      .input('precio', p.precio)
      .input('imagen_url', p.imagen_url)
      .input('stock', p.stock)
      .query(`INSERT INTO productos (nombre, descripcion, categoria, precio, imagen_url, stock)
              OUTPUT INSERTED.*
              VALUES (@nombre, @descripcion, @categoria, @precio, @imagen_url, @stock)`);
    return r.recordset[0];
  }

  async actualizar(id, p) {
    const r = await pool.request()
      .input('id', id)
      .input('nombre', p.nombre)
      .input('descripcion', p.descripcion)
      .input('categoria', p.categoria)
      .input('precio', p.precio)
      .input('imagen_url', p.imagen_url)
      .input('stock', p.stock)
      .query(`UPDATE productos SET nombre=@nombre, descripcion=@descripcion, categoria=@categoria, 
              precio=@precio, imagen_url=@imagen_url, stock=@stock
              OUTPUT INSERTED.* WHERE id = @id`);
    return r.recordset[0] || null;
  }

  async eliminar(id) {
    const r = await pool.request()
      .input('id', id)
      .query('DELETE FROM productos WHERE id = @id');
    return r.rowsAffected[0] > 0;
  }
}