import { Router } from 'express';
import { ProductRepository } from './product.repository.js';
import { ProductService } from '../application/product.service.js';
import { verificarToken } from '../../middlewares/auth.js';

const router = Router();
const service = new ProductService(new ProductRepository());

router.get('/', async (req, res, next) => {
  try { res.json(await service.listarProductos()); } catch (e) { next(e); }
});

router.get('/:id', async (req, res, next) => {
  try { res.json(await service.obtenerProducto(req.params.id)); } catch (e) { next(e); }
});

router.post('/', verificarToken, async (req, res, next) => {
  try { 
    const nuevo = await service.crearProducto(req.body);
    res.status(201).json(nuevo);
  } catch (e) { 
    if (e.status) return res.status(e.status).json({ error: e.message });
    next(e); 
  }
});

router.put('/:id', verificarToken, async (req, res, next) => {
  try {
    const act = await service.actualizarProducto(req.params.id, req.body);
    res.json(act);
  } catch (e) {
    if (e.status) return res.status(e.status).json({ error: e.message });
    next(e);
  }
});

router.delete('/:id', verificarToken, async (req, res, next) => {
  try {
    await service.eliminarProducto(req.params.id);
    res.status(204).end();
  } catch (e) {
    if (e.status) return res.status(e.status).json({ error: e.message });
    next(e);
  }
});

export default router;