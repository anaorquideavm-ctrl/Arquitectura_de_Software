import { Router } from 'express';
import { listarResenas, crearResena } from '../controllers/resenas.controller.js';

const router = Router();
router.get('/', listarResenas);
router.post('/', crearResena);

export default router;