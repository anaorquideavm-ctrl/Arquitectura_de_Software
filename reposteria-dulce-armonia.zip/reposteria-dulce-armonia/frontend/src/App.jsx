import { Routes, Route, Link, useNavigate } from 'react-router-dom';
import Catalog from './pages/Catalog';
import Login from './pages/Login';
import AdminProducts from './pages/AdminProducts';
import RutaProtegida from './RutaProtegida';

export default function App() {
  const navigate = useNavigate();
  const token = localStorage.getItem('token');
  const nombre = localStorage.getItem('nombre');

  const cerrarSesion = () => {
    localStorage.removeItem('token');
    localStorage.removeItem('nombre');
    navigate('/login');
  };

  return (
    <div style={{ fontFamily: 'Segoe UI, sans-serif', backgroundColor: '#FFFDF9', minHeight: '100vh', margin: 0 }}>
      <nav style={{ display: 'flex', justifyContent: 'space-between', padding: '1rem 2rem', backgroundColor: '#E07A5F', color: 'white', alignItems: 'center' }}>
        <h2 style={{ margin: 0 }}>Dulce Armonía | Repostería Saludable</h2>
        <div style={{ display: 'flex', gap: '1rem', alignItems: 'center' }}>
          <Link to="/" style={{ color: 'white', textDecoration: 'none', fontWeight: 'bold' }}>Catálogo</Link>
          {token ? (
            <>
              <Link to="/admin" style={{ color: 'white', textDecoration: 'none', fontWeight: 'bold' }}>Administración</Link>
              <span>| Hola, {nombre}</span>
              <button onClick={cerrarSesion} style={{ background: '#3D405B', color: 'white', border: 'none', padding: '0.5rem 1rem', borderRadius: '4px', cursor: 'pointer' }}>
                Cerrar Sesión
              </button>
            </>
          ) : (
            <Link to="/login" style={{ color: 'white', textDecoration: 'none', fontWeight: 'bold' }}>Iniciar Sesión</Link>
          )}
        </div>
      </nav>

      <div style={{ padding: '2rem' }}>
        <Routes>
          <Route path="/" element={<Catalog />} />
          <Route path="/login" element={<Login />} />
          <Route path="/admin" element={
            <RutaProtegida>
              <AdminProducts />
            </RutaProtegida>
          } />
        </Routes>
      </div>
    </div>
  );
}