import { useState } from 'react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { api } from '../api';

export default function AdminProducts() {
  const qc = useQueryClient();
  const [form, setForm] = useState({ nombre: '', descripcion: '', categoria: 'Sin Azúcar (Diabéticos)', precio: '', imagen_url: '', stock: '' });

  const { data: productos, isLoading } = useQuery({
    queryKey: ['productos'],
    queryFn: () => api('/productos'),
  });

  const crearMutation = useMutation({
    mutationFn: (nuevo) => api('/productos', { method: 'POST', body: nuevo }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['productos'] });
      setForm({ nombre: '', descripcion: '', categoria: 'Sin Azúcar (Diabéticos)', precio: '', imagen_url: '', stock: '' });
    },
  });

  const borrarMutation = useMutation({
    mutationFn: (id) => api(`/productos/${id}`, { method: 'DELETE' }),
    onSuccess: () => {
      qc.invalidateQueries({ queryKey: ['productos'] });
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    crearMutation.mutate(form);
  };

  if (isLoading) return <p>Cargando panel...</p>;

  return (
    <div style={{ display: 'grid', gridTemplateColumns: '1fr 2fr', gap: '2rem' }}>
      <form onSubmit={handleSubmit} style={{ backgroundColor: 'white', padding: '1.5rem', borderRadius: '8px', boxShadow: '0 2px 8px rgba(0,0,0,0.1)', display: 'flex', flexDirection: 'column', gap: '0.8rem' }}>
        <h3>Agregar Nuevo Postre</h3>
        {crearMutation.isError && <p style={{ color: 'red' }}>{crearMutation.error.message}</p>}
        <input placeholder="Nombre del postre" value={form.nombre} onChange={(e) => setForm({ ...form, nombre: e.target.value })} required />
        <textarea placeholder="Descripción detallada" value={form.descripcion} onChange={(e) => setForm({ ...form, descripcion: e.target.value })} required />
        <select value={form.categoria} onChange={(e) => setForm({ ...form, categoria: e.target.value })}>
          <option value="Sin Azúcar (Diabéticos)">Sin Azúcar (Diabéticos)</option>
          <option value="Sin Gluten (Celiacos)">Sin Gluten (Celiacos)</option>
          <option value="Sin Lactosa">Sin Lactosa</option>
          <option value="Keto / Fit">Keto / Fit</option>
        </select>
        <input type="number" step="0.01" placeholder="Precio (RD$)" value={form.precio} onChange={(e) => setForm({ ...form, precio: e.target.value })} required />
        <input placeholder="URL de la imagen" value={form.imagen_url} onChange={(e) => setForm({ ...form, imagen_url: e.target.value })} required />
        <input type="number" placeholder="Stock disponible" value={form.stock} onChange={(e) => setForm({ ...form, stock: e.target.value })} required />
        
        <button type="submit" disabled={crearMutation.isPending} style={{ backgroundColor: '#81B29A', color: 'white', padding: '0.8rem', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
          {crearMutation.isPending ? 'Guardando...' : 'Guardar Producto'}
        </button>
      </form>

      <div>
        <h3>Lista de Productos en Inventario</h3>
        <table style={{ width: '100%', borderCollapse: 'collapse', backgroundColor: 'white' }}>
          <thead>
            <tr style={{ backgroundColor: '#3D405B', color: 'white', textAlign: 'left' }}>
              <th style={{ padding: '0.8rem' }}>Producto</th>
              <th>Categoría</th>
              <th>Precio</th>
              <th>Acciones</th>
            </tr>
          </thead>
          <tbody>
            {productos?.map((p) => (
              <tr key={p.id} style={{ borderBottom: '1px solid #ddd' }}>
                <td style={{ padding: '0.8rem' }}>{p.nombre}</td>
                <td>{p.categoria}</td>
                <td>RD$ {p.precio.toFixed(2)}</td>
                <td>
                  <button onClick={() => borrarMutation.mutate(p.id)} style={{ backgroundColor: '#E07A5F', color: 'white', border: 'none', padding: '0.4rem 0.8rem', borderRadius: '4px', cursor: 'pointer' }}>
                    Eliminar
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}