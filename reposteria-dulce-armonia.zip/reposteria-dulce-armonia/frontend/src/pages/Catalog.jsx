import { useQuery } from '@tanstack/react-query';
import { api } from '../api';

export default function Catalog() {
  const { data: productos, isLoading, isError, error } = useQuery({
    queryKey: ['productos'],
    queryFn: () => api('/productos'),
  });

  if (isLoading) return <p style={{ textAlign: 'center' }}>Cargando nuestros deliciosos postres...</p>;
  if (isError) return <p style={{ textAlign: 'center', color: 'red' }}>Error: {error.message}</p>;

  return (
    <div>
      <header style={{ textAlign: 'center', marginBottom: '2.5rem' }}>
        <h1 style={{ color: '#3D405B' }}>Nuestros Postres Especiales</h1>
        <p style={{ color: '#81B29A', fontSize: '1.2rem', fontWeight: '600' }}>
          100% Libres de culpa: Opción para Diabéticos, Celiacos e Intolerantes a la Lactosa
        </p>
      </header>

      <div style={{ display: 'grid', gridTemplateColumns: 'repeat(auto-fill, minmax(280px, 1fr))', gap: '2rem' }}>
        {productos?.map((p) => (
          <div key={p.id} style={{ border: '1px solid #F4F1DE', borderRadius: '12px', overflow: 'hidden', boxShadow: '0 4px 10px rgba(0,0,0,0.05)', backgroundColor: 'white' }}>
            <img src={p.imagen_url} alt={p.nombre} style={{ width: '100%', height: '200px', objectFit: 'cover' }} />
            <div style={{ padding: '1.2rem' }}>
              <span style={{ backgroundColor: '#F2CC8F', color: '#3D405B', padding: '0.2rem 0.6rem', borderRadius: '20px', fontSize: '0.8rem', fontWeight: 'bold' }}>
                {p.categoria}
              </span>
              <h3 style={{ margin: '0.8rem 0 0.4rem 0', color: '#3D405B' }}>{p.nombre}</h3>
              <p style={{ color: '#666', fontSize: '0.9rem', minHeight: '40px' }}>{p.descripcion}</p>
              <div style={{ display: 'flex', justifyContent: 'space-between', alignItems: 'center', marginTop: '1rem' }}>
                <span style={{ fontSize: '1.4rem', fontWeight: 'bold', color: '#E07A5F' }}>RD$ {p.precio.toFixed(2)}</span>
                <span style={{ fontSize: '0.85rem', color: p.stock > 0 ? '#81B29A' : 'red', fontWeight: 'bold' }}>
                  {p.stock > 0 ? `Stock: ${p.stock}` : 'Agotado'}
                </span>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  );
}