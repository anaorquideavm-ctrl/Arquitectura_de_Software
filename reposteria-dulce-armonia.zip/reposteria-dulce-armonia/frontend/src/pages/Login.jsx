import { useState } from 'react';
import { useMutation } from '@tanstack/react-query';
import { useNavigate } from 'react-router-dom';
import { api } from '../api';

export default function Login() {
  const [isRegister, setIsRegister] = useState(false);
  const [nombre, setNombre] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mensaje, setMensaje] = useState('');
  const navigate = useNavigate();

  const authMutation = useMutation({
    mutationFn: (datos) => api(isRegister ? '/auth/registro' : '/auth/login', { method: 'POST', body: datos }),
    onSuccess: (data) => {
      if (isRegister) {
        setIsRegister(false);
        setMensaje('¡Registro exitoso! Ahora inicia sesión.');
      } else {
        localStorage.setItem('token', data.token);
        localStorage.setItem('nombre', data.nombre);
        navigate('/admin');
      }
    },
  });

  const handleSubmit = (e) => {
    e.preventDefault();
    setMensaje('');
    if (isRegister) {
      authMutation.mutate({ nombre, email, password });
    } else {
      authMutation.mutate({ email, password });
    }
  };

  return (
    <div style={{ maxWidth: '400px', margin: '3rem auto', padding: '2rem', backgroundColor: 'white', borderRadius: '8px', boxShadow: '0 4px 12px rgba(0,0,0,0.1)' }}>
      <h2 style={{ textAlign: 'center', color: '#3D405B' }}>{isRegister ? 'Crear Cuenta' : 'Iniciar Sesión'}</h2>
      {mensaje && <p style={{ color: 'green', textAlign: 'center' }}>{mensaje}</p>}
      {authMutation.isError && <p style={{ color: 'red', textAlign: 'center' }}>{authMutation.error.message}</p>}

      <form onSubmit={handleSubmit} style={{ display: 'flex', flexDirection: 'column', gap: '1rem' }}>
        {isRegister && (
          <input type="text" placeholder="Nombre completo" value={nombre} onChange={(e) => setNombre(e.target.value)} required style={{ padding: '0.8rem', borderRadius: '4px', border: '1px solid #ccc' }} />
        )}
        <input type="email" placeholder="Correo electrónico" value={email} onChange={(e) => setEmail(e.target.value)} required style={{ padding: '0.8rem', borderRadius: '4px', border: '1px solid #ccc' }} />
        <input type="password" placeholder="Contraseña" value={password} onChange={(e) => setPassword(e.target.value)} required style={{ padding: '0.8rem', borderRadius: '4px', border: '1px solid #ccc' }} />
        
        <button type="submit" disabled={authMutation.isPending} style={{ padding: '0.8rem', backgroundColor: '#E07A5F', color: 'white', border: 'none', borderRadius: '4px', cursor: 'pointer', fontWeight: 'bold' }}>
          {authMutation.isPending ? 'Procesando...' : isRegister ? 'Registrarse' : 'Entrar'}
        </button>
      </form>

      <button onClick={() => setIsRegister(!isRegister)} style={{ background: 'none', border: 'none', color: '#3D405B', marginTop: '1rem', width: '100%', cursor: 'pointer', textDecoration: 'underline' }}>
        {isRegister ? '¿Ya tienes cuenta? Inicia sesión' : '¿No tienes cuenta? Regístrate aquí'}
      </button>
    </div>
  );
}